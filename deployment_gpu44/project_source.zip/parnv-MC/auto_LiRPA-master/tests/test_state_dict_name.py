import torch
import torch.nn as nn
import torch.nn.functional as F
from auto_LiRPA import BoundedModule
from testcase import TestCase, DEFAULT_DEVICE, DEFAULT_DTYPE

class FeatureExtraction(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, 4, stride=2, padding=1)
        self.conv2 = nn.Conv2d(8, 16, 4, stride=2, padding=1)
        self.fc1 = nn.Linear(784, 256)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = x.view(-1, 784)
        x = F.relu(self.fc1(x))
        return x


class cnn_MNIST(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = BoundedModule(FeatureExtraction(), torch.empty((1, 1, 28, 28)))
        self.fc = nn.Linear(256, 10)

    def forward(self, x):
        x = self.features(x)
        return self.fc(x)


class TestStateDictName(TestCase):
    def __init__(self, methodName='runTest', generate=False, device=DEFAULT_DEVICE, dtype=DEFAULT_DTYPE):
        super().__init__(methodName, device=device, dtype=dtype)

    def test(self):
        model = cnn_MNIST().to(device=self.default_device, dtype=self.default_dtype)
        state_dict = model.state_dict()
        dummy = torch.randn((1, 1, 28, 28))
        ret1 = model(dummy)

        # create second model and load state_dict to test load_state_dict() whether works proper
        model = cnn_MNIST().to(device=self.default_device, dtype=self.default_dtype)
        model.load_state_dict(state_dict, strict=True)
        ret2 = model(dummy)
        self.assertEqual(ret1, ret2)


if __name__ == '__main__':
    # Change to generate=True when genearting reference results
    testcase = TestStateDictName(generate=False)
    testcase.test()
